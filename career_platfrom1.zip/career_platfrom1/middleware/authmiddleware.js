const jwt = require('jsonwebtoken');

// Middleware to verify token
const verifyToken = (req, res, next) => {
  const token = req.headers['authorization']?.split(' ')[1];
  if (!token) return res.status(403).json({ error: 'Token is required' });

  jwt.verify(token, process.env.SECRET_KEY, (err, decoded) => {
    if (err) return res.status(403).json({ error: 'Invalid token' });
    req.user = decoded; // Attach decoded token (user info) to the request
    next();
  });
};

// Check if user is an admin
const isAdmin = (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
};

// Check if user is an employer
const isEmployer = (req, res, next) => {
  if (req.user.role !== 'employer') {
    return res.status(403).json({ error: 'Employer access required' });
  }
  next();
};

// Check if user is a job seeker
const isJobSeeker = (req, res, next) => {
  if (req.user.role !== 'job_seeker') {
    return res.status(403).json({ error: 'Job Seeker access required' });
  }
  next();
};

module.exports = { verifyToken, isAdmin, isEmployer, isJobSeeker };
