const db = require('../config/db');

// Log admin activity
const logActivity = async (adminId, action) => {
  await db.execute('INSERT INTO admin_activity_log (admin_id, action) VALUES (?, ?)', [adminId, action]);
};

// Get admin activity logs
const getLogs = async () => {
  const [rows] = await db.execute('SELECT * FROM admin_activity_log ORDER BY performed_at DESC');
  return rows;
};

module.exports = {
  logActivity,
  getLogs,
};
