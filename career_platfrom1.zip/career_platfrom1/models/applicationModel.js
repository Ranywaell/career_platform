const db = require('../config/db');

/**
 * Create a new application.
 */
const createApplication = async (userId, listingId) => {
  const [rows] = await db.execute(
    'INSERT INTO applications (user_id, listing_id) VALUES (?, ?)',
    [userId, listingId]
  );
  return rows.insertId;
};

/**
 * Get all applications (used by Admin).
 */
const getAllApplications = async () => {
  const [rows] = await db.execute('SELECT * FROM applications');
  return rows;
};

/**
 * Employer: get applications for a specific listing (JOIN to get user’s name).
 */
const getApplicationsForListing = async (listingId, employerId) => {
  const [rows] = await db.execute(
    `SELECT
       a.id AS application_id,
       a.user_id,
       u.name AS user_name,
       a.status,
       a.applied_at
     FROM applications a
     JOIN listings l ON a.listing_id = l.id
     JOIN users u ON a.user_id = u.id
     WHERE a.listing_id = ?
       AND l.posted_by = ?`,
    [listingId, employerId]
  );
  return rows;
};

/**
 * Employer: get all applications for all of their listings (JOIN).
 */
const getAllApplicationsForEmployer = async (employerId) => {
  const [rows] = await db.execute(
    `SELECT
       a.id AS application_id,
       a.user_id,
       u.name AS user_name,
       a.status,
       a.applied_at,
       l.id AS listing_id,
       l.title AS listing_title,
       l.category
     FROM applications a
     JOIN listings l ON a.listing_id = l.id
     JOIN users u ON a.user_id = u.id
     WHERE l.posted_by = ?`,
    [employerId]
  );
  return rows;
};

/**
 * Admin: get all applications for a specific job seeker.
 */
const getApplicationsByJobSeeker = async (userId) => {
  const [rows] = await db.execute(
    'SELECT * FROM applications WHERE user_id = ?',
    [userId]
  );
  return rows;
};

/**
 * Employer: update application status.
 */
const updateApplicationStatus = async (applicationId, status, employerId) => {
  const [rows] = await db.execute(
    `UPDATE applications a
     JOIN listings l ON a.listing_id = l.id
     SET a.status = ?
     WHERE a.id = ? AND l.posted_by = ?`,
    [status, applicationId, employerId]
  );
  return rows.affectedRows;
};

module.exports = {
  createApplication,
  getAllApplications,
  getAllApplicationsForEmployer,
  getApplicationsForListing,
  getApplicationsByJobSeeker,
  updateApplicationStatus,
};
