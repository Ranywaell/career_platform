const db = require('../config/db');
const bcrypt = require('bcryptjs');

// Create a new user
const createUser = async (name, email, password, role) => {
  const hashedPassword = await bcrypt.hash(password, 10);
  const [rows] = await db.execute(
    'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)',
    [name, email, hashedPassword, role]
  );
  return rows.insertId;
};

// Find by email
const findUserByEmail = async (email) => {
  const [rows] = await db.execute('SELECT * FROM users WHERE email = ?', [email]);
  return rows[0];
};

// Find by ID
const findUserById = async (id) => {
  const [rows] = await db.execute('SELECT * FROM users WHERE id = ?', [id]);
  return rows[0];
};

// Update user profile
const updateUserProfile = async (id, name, email) => {
  const [rows] = await db.execute(
    'UPDATE users SET name = ?, email = ? WHERE id = ?',
    [name, email, id]
  );
  return rows.affectedRows;
};

const getAllUsers = async () => {
  const [rows] = await db.execute('SELECT * FROM users');
  return rows;
};

const deleteUser = async (id) => {
  const [rows] = await db.execute('DELETE FROM users WHERE id = ?', [id]);
  return rows;
};

// Employer dashboard data
const getEmployerDashboard = async (employerId) => {
  const [rows] = await db.execute(
    'SELECT id, title, description, category, location, salary, created_at FROM listings WHERE posted_by = ?',
    [employerId]
  );
  return rows;
};

// Additional role or status updates if needed
const updateUserRole = async (id, role) => {
  const [rows] = await db.execute('UPDATE users SET role = ? WHERE id = ?', [role, id]);
  return rows.affectedRows;
};

// const updateUserStatus = async (id, status) => {
//   const [rows] = await db.execute('UPDATE users SET status = ? WHERE id = ?', [status, id]);
//   return rows.affectedRows;
// };

module.exports = {
  createUser,
  findUserByEmail,
  findUserById,
  updateUserProfile,
  getAllUsers,
  deleteUser,
  getEmployerDashboard,
  updateUserRole,
};
