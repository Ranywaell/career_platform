const db = require('../config/db');

/**
 * If you want to truly link to 'categories' table by ID, 
 * you'd store category_id in listings.
 * For now, we store category as a simple VARCHAR(100).
 */
const createListing = async (title, description, category, location, salary, postedBy) => {
  const [rows] = await db.execute(
    'INSERT INTO listings (title, description, category, location, salary, posted_by) VALUES (?, ?, ?, ?, ?, ?)',
    [title, description, category, location, salary, postedBy]
  );
  return rows.insertId;
};

const getAllListings = async () => {
  const [rows] = await db.execute('SELECT * FROM listings');
  return rows;
};

const getListingById = async (id) => {
  const [rows] = await db.execute('SELECT * FROM listings WHERE id = ?', [id]);
  return rows[0];
};

const updateListing = async (id, title, description, category, location, salary, postedBy) => {
  const [rows] = await db.execute(
    'UPDATE listings SET title = ?, description = ?, category = ?, location = ?, salary = ? WHERE id = ? AND posted_by = ?',
    [title, description, category, location, salary, id, postedBy]
  );
  return rows.affectedRows;
};

const deleteListing = async (id, postedBy) => {
  const [rows] = await db.execute(
    'DELETE FROM listings WHERE id = ? AND posted_by = ?',
    [id, postedBy]
  );
  return rows.affectedRows;
};

module.exports = {
  createListing,
  getAllListings,
  getListingById,
  updateListing,
  deleteListing,
};
