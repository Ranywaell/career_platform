const db = require('../config/db');

// Create a new category
const createCategory = async (name) => {
  const [rows] = await db.execute('INSERT INTO categories (name) VALUES (?)', [name]);
  return rows.insertId; // Return the new category's ID
};

// Get all categories
const getAllCategories = async () => {
  const [rows] = await db.execute('SELECT * FROM categories');
  return rows;
};

// Update a category
const updateCategory = async (id, name) => {
  const [rows] = await db.execute('UPDATE categories SET name = ? WHERE id = ?', [name, id]);
  return rows.affectedRows; // Number of rows updated
};

// Delete a category
const deleteCategory = async (id) => {
  const [rows] = await db.execute('DELETE FROM categories WHERE id = ?', [id]);
  return rows.affectedRows; // Number of rows deleted
};

module.exports = {
  createCategory,
  getAllCategories,
  updateCategory,
  deleteCategory,
};
