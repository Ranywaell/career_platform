const Category = require('../models/categoryModel');

// Admin: Create a new category
const createCategory = async (req, res) => {
  const { name } = req.body;
  try {
    const categoryId = await Category.createCategory(name);
    return res.status(201).json({ message: 'Category created successfully', categoryId });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to create category' });
  }
};

// Public: Get all categories
const getAllCategories = async (req, res) => {
  try {
    const categories = await Category.getAllCategories();
    return res.status(200).json(categories);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to fetch categories' });
  }
};

// Admin: Update a category
const updateCategory = async (req, res) => {
  const { id } = req.params;
  const { name } = req.body;
  try {
    const result = await Category.updateCategory(id, name);
    if (!result) {
      return res.status(404).json({ error: 'Category not found' });
    }
    return res.status(200).json({ message: 'Category updated successfully' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to update category' });
  }
};

// Admin: Delete a category
const deleteCategory = async (req, res) => {
  const { id } = req.params;
  try {
    const result = await Category.deleteCategory(id);
    if (!result) {
      return res.status(404).json({ error: 'Category not found' });
    }
    return res.status(200).json({ message: 'Category deleted successfully' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to delete category' });
  }
};

module.exports = {
  createCategory,
  getAllCategories,
  updateCategory,
  deleteCategory,
};
