const Listing = require('../models/listingModel');

const createListing = async (req, res) => {
  const { title, description, category, location, salary } = req.body;
  const postedBy = req.user.id; // Employer ID
  try {
    const newListingId = await Listing.createListing(title, description, category, location, salary, postedBy);
    return res.status(201).json({ message: 'Listing created successfully', listingId: newListingId });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to create listing' });
  }
};

const getAllListings = async (req, res) => {
  try {
    const listings = await Listing.getAllListings();
    return res.status(200).json(listings);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to fetch listings' });
  }
};

const getListingById = async (req, res) => {
  const { id } = req.params;
  try {
    const listing = await Listing.getListingById(id);
    if (!listing) {
      return res.status(404).json({ error: 'Listing not found' });
    }
    return res.status(200).json(listing);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to fetch listing' });
  }
};

const updateListing = async (req, res) => {
  const { id } = req.params;
  const { title, description, category, location, salary } = req.body;
  const postedBy = req.user.id;  // Employer ID
  try {
    const updatedListing = await Listing.updateListing(id, title, description, category, location, salary, postedBy);
    if (updatedListing === 0) {
      return res.status(403).json({ error: 'You can only update listings that you posted' });
    }
    return res.status(200).json({ message: 'Listing updated successfully' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to update listing' });
  }
};

const deleteListing = async (req, res) => {
  const { id } = req.params;
  const postedBy = req.user.id;
  try {
    const deletedListing = await Listing.deleteListing(id, postedBy);
    if (deletedListing === 0) {
      return res.status(403).json({ error: 'You can only delete listings that you posted' });
    }
    return res.status(200).json({ message: 'Listing deleted successfully' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to delete listing' });
  }
};

module.exports = {
  createListing,
  getAllListings,
  getListingById,
  updateListing,
  deleteListing,
};
