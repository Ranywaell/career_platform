const Application = require('../models/applicationModel');

/**
 * Job Seeker: Apply for a job.
 */
const applyForJob = async (req, res) => {
  const { listingId } = req.body;
  const userId = req.user.id;
  try {
    const applicationId = await Application.createApplication(userId, listingId);
    return res.status(201).json({ message: 'Application submitted successfully', applicationId });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to apply for the job' });
  }
};

/**
 * GET /api/applications
 * If admin -> returns all applications.
 * If employer -> returns all applications for that employer's listings (with user name).
 */
const getAllApplications = async (req, res) => {
  try {
    if (req.user.role === 'admin') {
      const apps = await Application.getAllApplications();
      return res.status(200).json(apps);
    } else if (req.user.role === 'employer') {
      const apps = await Application.getAllApplicationsForEmployer(req.user.id);
      return res.status(200).json(apps);
    } else {
      return res.status(403).json({ error: 'Access denied' });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to fetch applications' });
  }
};

const getMyApplications = async (req, res) => {
  try {
    // The authenticated user’s ID from the JWT
    const userId = req.user.id;
    // Use your model method
    const apps = await Application.getApplicationsByJobSeeker(userId);
    return res.status(200).json(apps);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to fetch your applications' });
  }
};
/**
 * Employer: get applications for a specific listing.
 */
const getApplicationsByListing = async (req, res) => {
  const { listingId } = req.params;
  const employerId = req.user.id;
  try {
    const applications = await Application.getApplicationsForListing(listingId, employerId);
    return res.status(200).json(applications);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to fetch applications' });
  }
};


/**
 * Admin: get applications by a specific job seeker.
 */
const getApplicationsByJobSeeker = async (req, res) => {
  const { userId } = req.params;
  try {
    const applications = await Application.getApplicationsByJobSeeker(userId);
    return res.status(200).json(applications);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to fetch applications' });
  }
};

/**
 * Employer: update application status.
 */
const updateApplicationStatus = async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  const employerId = req.user.id;
  try {
    const result = await Application.updateApplicationStatus(id, status, employerId);
    if (!result) {
      return res.status(404).json({ error: 'Application not found or not authorized' });
    }
    return res.status(200).json({ message: 'Application status updated successfully' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to update application status' });
  }
};

module.exports = {
  applyForJob,
  getAllApplications,
  getMyApplications,
  getApplicationsByListing,
  getApplicationsByJobSeeker,
  updateApplicationStatus,
};
