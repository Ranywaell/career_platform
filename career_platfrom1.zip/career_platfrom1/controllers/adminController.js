const Admin = require('../models/adminModel');
const User = require('../models/userModel');

// Get all users
const getAllUsers = async (req, res) => {
  try {
    const users = await User.getAllUsers();
    return res.status(200).json(users);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to fetch users' });
  }
};

// Get user by ID
const getUserById = async (req, res) => {
  const { id } = req.params;
  try {
    const user = await User.findUserById(id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    return res.status(200).json(user);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to fetch user' });
  }
};

// Delete a user
const deleteUser = async (req, res) => {
  const { id } = req.params;
  try {
    const result = await User.deleteUser(id);
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    await Admin.logActivity(req.user.id, `Deleted user with ID: ${id}`);
    return res.status(200).json({ message: 'User deleted successfully' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to delete user' });
  }
};

// Update user role
const updateUserRole = async (req, res) => {
  const { id } = req.params;
  const { role } = req.body;
  try {
    const result = await User.updateUserRole(id, role);
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    await Admin.logActivity(req.user.id, `Updated role for user ID: ${id} to ${role}`);
    return res.status(200).json({ message: 'User role updated successfully' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to update user role' });
  }
};

// // Deactivate/Reactivate user
// const toggleUserStatus = async (req, res) => {
//   const { id } = req.params;
//   const { status } = req.body; // Expected: 'active' or 'inactive'
//   try {
//     const result = await User.updateUserStatus(id, status);
//     if (result.affectedRows === 0) {
//       return res.status(404).json({ error: 'User not found' });
//     }
//     await Admin.logActivity(req.user.id, `${status === 'active' ? 'Reactivated' : 'Deactivated'} user ID: ${id}`);
//     return res.status(200).json({ message: `User status updated to ${status}` });
//   } catch (err) {
//     console.error(err);
//     return res.status(500).json({ error: 'Failed to update user status' });
//   }
// };

// Get admin activity logs
const getAdminLogs = async (req, res) => {
  try {
    const logs = await Admin.getLogs();
    return res.status(200).json(logs);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to fetch activity logs' });
  }
};

module.exports = {
  getAllUsers,
  getUserById,
  deleteUser,
  updateUserRole,
  toggleUserStatus,
  getAdminLogs,
};
