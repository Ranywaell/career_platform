const mysql = require('mysql2');
require('dotenv').config();  // Ensure .env is loaded

const db = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
});

// Test connection and log status
db.getConnection((err, connection) => {
    if (err) {
        console.error('Database connection failed:', err.message);
        return;
    }
    console.log(`Connected to ${process.env.DB_NAME} database as ID ${connection.threadId}`);
    connection.release();  // Release the connection back to the pool
});

module.exports = db.promise();  // Using promises for queries
