// admin_dashboard.js

document.addEventListener('DOMContentLoaded', () => {
    const logoutLink = document.getElementById('logout-link');
    const fetchUsersBtn = document.getElementById('fetch-users-btn');
    const fetchLogsBtn = document.getElementById('fetch-logs-btn');
  
    // Logout link
    if (logoutLink) {
      logoutLink.addEventListener('click', (e) => {
        e.preventDefault();
        localStorage.removeItem('token');
        window.location.href = '/htmls/login.html';
      });
    }
  
    // Buttons
    if (fetchUsersBtn) {
      fetchUsersBtn.addEventListener('click', loadAllUsers);
    }
    if (fetchLogsBtn) {
      fetchLogsBtn.addEventListener('click', loadAdminLogs);
    }
  });
  
  // ======================
  // LOAD ALL USERS
  async function loadAllUsers() {
    const token = localStorage.getItem('token');
    if (!token) {
      alert('Admin access required!');
      window.location.href = '/htmls/login.html';
      return;
    }
  
    try {
      const response = await fetch('http://localhost:3000/api/admin/users', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const data = await response.json();
  
      const usersContainer = document.getElementById('all-users');
      usersContainer.innerHTML = '';
  
      if (!response.ok) {
        throw new Error(data.error || 'Error fetching users');
      }
  
      if (Array.isArray(data) && data.length > 0) {
        data.forEach((user) => {
          const userDiv = document.createElement('div');
          userDiv.classList.add('job-listing'); // reusing the style for simplicity
          userDiv.innerHTML = `
            <p><strong>ID:</strong> ${user.id}</p>
            <p><strong>Name:</strong> ${user.name}</p>
            <p><strong>Email:</strong> ${user.email}</p>
            <p><strong>Role:</strong> ${user.role}</p>
            <p><strong>Status:</strong> ${user.status || 'active'}</p>
            <button class="role-btn" data-id="${user.id}">Change Role</button>
            <button class="delete-user-btn" data-id="${user.id}">Delete</button>
          `;
          usersContainer.appendChild(userDiv);
  
          // Buttons
          userDiv.querySelector('.role-btn').addEventListener('click', () => {
            changeUserRole(user.id);
          });
          
          userDiv.querySelector('.delete-user-btn').addEventListener('click', () => {
            deleteUser(user.id);
          });
        });
      } else {
        usersContainer.innerHTML = '<p>No users found.</p>';
      }
    } catch (error) {
      console.error('Error fetching users:', error);
      alert('An error occurred while fetching users.');
    }
  }
  
  // ======================
  // CHANGE USER ROLE
  async function changeUserRole(userId) {
    const token = localStorage.getItem('token');
    if (!token) return;
  
    const newRole = prompt('Enter new role (admin, employer, job_seeker):');
    if (!newRole) return;
  
    try {
      const response = await fetch(`http://localhost:3000/api/admin/user/${userId}/role`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ role: newRole }),
      });
      const data = await response.json();
  
      if (!response.ok) {
        throw new Error(data.error || 'Error changing user role');
      }
  
      alert(`User role updated to ${newRole} successfully!`);
      loadAllUsers();
    } catch (error) {
      console.error('Error changing user role:', error);
      alert('An error occurred while changing user role.');
    }
  }
  
  // ======================
  // TOGGLE USER STATUS
//   async function toggleUserStatus(userId, status) {
//     const token = localStorage.getItem('token');
//     if (!token) return;
  
//     try {
//       const response = await fetch(`http://localhost:3000/api/admin/user/${userId}/status`, {
//         method: 'PUT',
//         headers: {
//           'Content-Type': 'application/json',
//           'Authorization': `Bearer ${token}`,
//         },
//         body: JSON.stringify({ status }),
//       });
//       const data = await response.json();
  
//       if (!response.ok) {
//         throw new Error(data.error || 'Error updating user status');
//       }
//       alert(`User status updated to ${status} successfully!`);
//       loadAllUsers();
//     } catch (error) {
//       console.error('Error updating user status:', error);
//       alert('An error occurred while updating user status.');
//     }
//   }
  
  // ======================
  // DELETE USER
  async function deleteUser(userId) {
    const token = localStorage.getItem('token');
    if (!token) return;
  
    if (!confirm('Are you sure you want to delete this user?')) return;
  
    try {
      const response = await fetch(`http://localhost:3000/api/admin/user/${userId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const data = await response.json();
  
      if (!response.ok) {
        throw new Error(data.error || 'Error deleting user');
      }
  
      alert('User deleted successfully!');
      loadAllUsers();
    } catch (error) {
      console.error('Error deleting user:', error);
      alert('An error occurred while deleting user.');
    }
  }
  
  // ======================
  // LOAD ADMIN LOGS
  async function loadAdminLogs() {
    const token = localStorage.getItem('token');
    if (!token) return;
  
    try {
      const response = await fetch('http://localhost:3000/api/admin/logs', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const data = await response.json();
  
      const logsContainer = document.getElementById('admin-logs');
      logsContainer.innerHTML = '';
  
      if (!response.ok) {
        throw new Error(data.error || 'Error fetching admin logs');
      }
  
      if (Array.isArray(data) && data.length > 0) {
        data.forEach((log) => {
          const logDiv = document.createElement('div');
          logDiv.classList.add('application-card');
          logDiv.innerHTML = `
            <p><strong>Admin ID:</strong> ${log.admin_id}</p>
            <p><strong>Action:</strong> ${log.action}</p>
            <p><strong>Performed At:</strong> ${new Date(log.performed_at).toLocaleString()}</p>
          `;
          logsContainer.appendChild(logDiv);
        });
      } else {
        logsContainer.innerHTML = '<p>No admin logs found.</p>';
      }
    } catch (error) {
      console.error('Error fetching admin logs:', error);
      alert('An error occurred while fetching admin logs.');
    }
  }
  