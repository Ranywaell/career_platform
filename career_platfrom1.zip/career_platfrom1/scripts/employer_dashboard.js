// scripts/employer_dashboard.js

document.addEventListener('DOMContentLoaded', () => {
    const createListingForm = document.getElementById('create-listing-form');
    const logoutLink = document.getElementById('logout-link');
  
    // Logout
    if (logoutLink) {
      logoutLink.addEventListener('click', (e) => {
        e.preventDefault();
        localStorage.removeItem('token');
        window.location.href = '/htmls/login.html';
      });
    }
  
    // Create listing
    if (createListingForm) {
      createListingForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        await createListing();
      });
    }
  
    // Load data on page load
    loadEmployerListings();
    loadEmployerApplications();
  });
  
  // CREATE A NEW LISTING
  async function createListing() {
    const token = localStorage.getItem('token');
    if (!token) {
      alert('You must be logged in to create listings!');
      window.location.href = '/htmls/login.html';
      return;
    }
  
    const title = document.getElementById('title').value;
    const description = document.getElementById('description').value;
    const category = document.getElementById('category').value;
    const location = document.getElementById('location').value;
    const salary = document.getElementById('salary').value;
  
    try {
      const response = await fetch('http://localhost:3000/api/listings/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ title, description, category, location, salary }),
      });
      const result = await response.json();
  
      if (!response.ok) {
        throw new Error(result.error || 'Error creating listing');
      }
  
      alert('Listing created successfully!');
      loadEmployerListings();
      document.getElementById('create-listing-form').reset();
    } catch (error) {
      console.error('Error creating listing:', error);
      alert('An error occurred while creating the listing.');
    }
  }
  
  // LOAD EMPLOYER LISTINGS
  async function loadEmployerListings() {
    const token = localStorage.getItem('token');
    if (!token) return;
  
    try {
      const response = await fetch('http://localhost:3000/api/listings', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const data = await response.json();
  
      const listingsContainer = document.getElementById('employer-listings');
      if (!listingsContainer) return;
      listingsContainer.innerHTML = '';
  
      if (!response.ok) {
        throw new Error(data.error || 'Error fetching listings');
      }
  
      const allListings = Array.isArray(data) ? data : data.listings;
      if (!allListings || allListings.length === 0) {
        listingsContainer.innerHTML = '<p>No listings found.</p>';
        return;
      }
  
      allListings.forEach((listing) => {
        // Optionally filter only listings posted by this employer, if needed.
        // if (listing.posted_by !== [employerId]) return;
  
        const listingDiv = document.createElement('div');
        listingDiv.classList.add('job-listing');
        listingDiv.innerHTML = `
          <h3>${listing.title}</h3>
          <p>${listing.description}</p>
          <p><strong>Category:</strong> ${listing.category || 'N/A'}</p>
          <p><strong>Location:</strong> ${listing.location || 'N/A'}</p>
          <p><strong>Salary:</strong> ${listing.salary || 'N/A'}</p>
          <p><strong>Created At:</strong> ${listing.created_at}</p>
          <button class="edit-listing-btn" data-id="${listing.id}">Edit</button>
          <button class="delete-listing-btn" data-id="${listing.id}">Delete</button>
        `;
        listingsContainer.appendChild(listingDiv);
  
        listingDiv.querySelector('.edit-listing-btn').addEventListener('click', () => {
          editListingPrompt(listing);
        });
        listingDiv.querySelector('.delete-listing-btn').addEventListener('click', () => {
          deleteListing(listing.id);
        });
      });
    } catch (error) {
      console.error('Error fetching employer listings:', error);
    }
  }
  
  // PROMPT FOR EDITING A LISTING
  async function editListingPrompt(listing) {
    const newTitle = prompt('New Title:', listing.title);
    if (newTitle === null) return;
  
    const newDesc = prompt('New Description:', listing.description);
    if (newDesc === null) return;
  
    const newCategory = prompt('New Category:', listing.category || '');
    if (newCategory === null) return;
  
    const newLocation = prompt('New Location:', listing.location || '');
    if (newLocation === null) return;
  
    const newSalary = prompt('New Salary:', listing.salary || '');
    if (newSalary === null) return;
  
    await updateListing(listing.id, newTitle, newDesc, newCategory, newLocation, newSalary);
  }
  
  // UPDATE A LISTING
  async function updateListing(id, title, description, category, location, salary) {
    const token = localStorage.getItem('token');
    if (!token) {
      alert('You must be logged in!');
      window.location.href = '/htmls/login.html';
      return;
    }
  
    try {
      const response = await fetch(`http://localhost:3000/api/listings/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ title, description, category, location, salary }),
      });
      const result = await response.json();
  
      if (!response.ok) {
        throw new Error(result.error || 'Error updating listing');
      }
      alert('Listing updated successfully!');
      loadEmployerListings();
    } catch (error) {
      console.error('Error updating listing:', error);
      alert('An error occurred while updating the listing.');
    }
  }
  
  // DELETE A LISTING
  async function deleteListing(id) {
    const token = localStorage.getItem('token');
    if (!token) {
      alert('You must be logged in!');
      window.location.href = '/htmls/login.html';
      return;
    }
  
    if (!confirm('Are you sure you want to delete this listing?')) {
      return;
    }
  
    try {
      const response = await fetch(`http://localhost:3000/api/listings/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const result = await response.json();
  
      if (!response.ok) {
        throw new Error(result.error || 'Error deleting listing');
      }
  
      alert('Listing deleted successfully!');
      loadEmployerListings();
    } catch (error) {
      console.error('Error deleting listing:', error);
      alert('An error occurred while deleting the listing.');
    }
  }
  
  // LOAD EMPLOYER APPLICATIONS
  async function loadEmployerApplications() {
    const token = localStorage.getItem('token');
    if (!token) return;
  
    try {
      // GET /api/applications => in applicationController, if employer => getAllApplicationsForEmployer
      const response = await fetch('http://localhost:3000/api/applications', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const data = await response.json();
  
      const appsContainer = document.getElementById('employer-applications');
      if (!appsContainer) return;
      appsContainer.innerHTML = '';
  
      if (!response.ok) {
        throw new Error(data.error || 'Error fetching employer applications');
      }
  
      const apps = Array.isArray(data) ? data : data.applications;
      if (!apps || apps.length === 0) {
        appsContainer.innerHTML = '<p>No applications found for your listings.</p>';
        return;
      }
  
      apps.forEach((app) => {
        /**
         * Each "app" might have:
         *   - application_id
         *   - user_id
         *   - user_name
         *   - status
         *   - applied_at
         *   - listing_id
         *   - listing_title
         *   - category
         */
        const appDiv = document.createElement('div');
        appDiv.classList.add('application-card');
        appDiv.innerHTML = `
          <p><strong>Application ID:</strong> ${app.application_id || app.id}</p>
          <p><strong>Applicant Name:</strong> ${app.user_name || 'Unknown'} (User ID: ${app.user_id})</p>
          <p><strong>Listing:</strong> ${app.listing_title || 'N/A'} (ID: ${app.listing_id || 'N/A'})</p>
          <p><strong>Status:</strong> ${app.status}</p>
          <p><strong>Applied At:</strong> ${new Date(app.applied_at).toLocaleString()}</p>
          <button class="update-status-btn" data-id="${app.application_id || app.id}">Update Status</button>
        `;
        appsContainer.appendChild(appDiv);
  
        appDiv.querySelector('.update-status-btn').addEventListener('click', () => {
          updateApplicationStatus(app.application_id || app.id);
        });
      });
    } catch (error) {
      console.error('Error fetching employer applications:', error);
      // You can show an error message in appsContainer if desired
    }
  }
  
  // UPDATE APPLICATION STATUS
  async function updateApplicationStatus(applicationId) {
    const token = localStorage.getItem('token');
    if (!token) {
      alert('You must be logged in!');
      window.location.href = '/htmls/login.html';
      return;
    }
  
    const newStatus = prompt('Enter new status (accepted/rejected/pending):');
    if (!newStatus) return;
  
    try {
      const response = await fetch(`http://localhost:3000/api/applications/${applicationId}/status`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ status: newStatus }),
      });
      const result = await response.json();
  
      if (!response.ok) {
        throw new Error(result.error || 'Error updating application status');
      }
  
      alert('Application status updated successfully!');
      loadEmployerApplications();
    } catch (error) {
      console.error('Error updating application status:', error);
      alert('An error occurred while updating the application status.');
    }
  }
  