// script.js

document.addEventListener('DOMContentLoaded', () => {
    const logoutLink = document.getElementById('logout-link');
    if (logoutLink) {
      logoutLink.addEventListener('click', (e) => {
        e.preventDefault();
        localStorage.removeItem('token');
        window.location.href = '/htmls/login.html';
      });
    }
  
    // If on job seeker dashboard
    if (window.location.pathname.endsWith('job_seeker_dashboard.html')) {
      loadJobListings();
      loadApplications();
    }
  });
  
  // ======================
  // REGISTER
  document.getElementById('register-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
  
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const role = document.getElementById('role').value;
  
    try {
      const response = await fetch('http://localhost:3000/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password, role }),
      });
      const data = await response.json();
  
      if (!response.ok) throw new Error(data.error || 'Registration failed');
  
      alert('Registration successful!');
      window.location.href = '/htmls/login.html';
    } catch (err) {
      alert(`Error: ${err.message}`);
    }
  });
  
  // ======================
  // LOGIN
  document.getElementById('login-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
  
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
  
    try {
      const response = await fetch('http://localhost:3000/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await response.json();
  
      if (!response.ok) throw new Error(data.error || 'Login failed');
  
      localStorage.setItem('token', data.token);
      alert('Login successful!');
  
      const payload = JSON.parse(atob(data.token.split('.')[1]));
      const role = payload.role;
  
      if (role === 'admin') {
        window.location.href = '/htmls/admin_dashboard.html';
      } else if (role === 'employer') {
        window.location.href = '/htmls/employer_dashboard.html';
      } else {
        window.location.href = '/htmls/job_seeker_dashboard.html';
      }
    } catch (err) {
      alert(`Error: ${err.message}`);
    }
  });
  
  // ======================
  // JOB SEEKER: LOAD LISTINGS
  async function loadJobListings() {
    const token = localStorage.getItem('token');
    if (!token) {
      alert('Please log in first');
      window.location.href = '/htmls/login.html';
      return;
    }
  
    try {
      const response = await fetch('http://localhost:3000/api/listings', {
        method: 'GET',
        headers: { 'Authorization': `Bearer ${token}` },
      });
      const data = await response.json();
  
      const container = document.getElementById('job-listings');
      if (!container) return;
  
      container.innerHTML = '';
      if (!response.ok) throw new Error(data.error || 'Error fetching job listings');
  
      const listings = Array.isArray(data) ? data : data.listings;
      if (!listings || listings.length === 0) {
        container.innerHTML = '<p>No job listings available.</p>';
        return;
      }
  
      listings.forEach((listing) => {
        const div = document.createElement('div');
        div.classList.add('job-listing');
        div.innerHTML = `
          <h3>${listing.title}</h3>
          <p>${listing.description}</p>
          <button class="apply-btn" data-id="${listing.id}">Apply</button>
        `;
        container.appendChild(div);
  
        div.querySelector('.apply-btn').addEventListener('click', applyForJob);
      });
    } catch (err) {
      console.error(err);
      alert('Error loading job listings');
    }
  }
  
  // ======================
  // JOB SEEKER: APPLY
  async function applyForJob(e) {
    const jobId = e.target.getAttribute('data-id');
    const token = localStorage.getItem('token');
    if (!token) {
      alert('You must be logged in to apply');
      window.location.href = '/htmls/login.html';
      return;
    }
  
    try {
      const response = await fetch('http://localhost:3000/api/applications/apply', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ listingId: jobId }),
      });
      const data = await response.json();
  
      if (!response.ok) throw new Error(data.error || 'Error applying for job');
  
      alert('Application submitted successfully!');
      loadApplications();
    } catch (err) {
      console.error(err);
      alert('Error applying for job.');
    }
  }
  
  // ======================
  // JOB SEEKER: LOAD APPLICATIONS
  async function loadApplications() {
    const token = localStorage.getItem('token');
    if (!token) {
      alert('Please log in first');
      window.location.href = '/htmls/login.html';
      return;
    }
  
    try {
      // Job seeker calls the dedicated '/my' route
      const response = await fetch('http://localhost:3000/api/applications/my', {
        method: 'GET',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await response.json();
  
      const appsContainer = document.getElementById('applications');
      if (!appsContainer) return;
      appsContainer.innerHTML = '';
  
      if (!response.ok) throw new Error(data.error || 'Error fetching applications');
  
      const apps = Array.isArray(data) ? data : data.applications;
      if (!apps || apps.length === 0) {
        appsContainer.innerHTML = '<p>No applications found.</p>';
        return;
      }
  
      apps.forEach((app) => {
        const appDiv = document.createElement('div');
        appDiv.classList.add('application-card');
        appDiv.innerHTML = `
          <p><strong>Listing ID:</strong> ${app.listing_id}</p>
          <p><strong>Status:</strong> ${app.status}</p>
          <p><strong>Applied At:</strong> ${new Date(app.applied_at).toLocaleString()}</p>
        `;
        appsContainer.appendChild(appDiv);
      });
    } catch (err) {
      console.error(err);
      alert('An error occurred while fetching your applications.');
    }
  }
  