document.addEventListener('DOMContentLoaded', async () => {
    const token = localStorage.getItem('token');
    if (!token) {
      alert('Please log in first');
      window.location.href = '/htmls/login.html';
      return;
    }
  
    // Fetch user info to display
    await loadUserInfo();
  
    // Handle update form
    const updateForm = document.getElementById('update-profile-form');
    if (updateForm) {
      updateForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        await updateUserProfile();
      });
    }
  });
  
  async function loadUserInfo() {
    const token = localStorage.getItem('token');
    try {
      const response = await fetch('http://localhost:3000/api/auth/profile', {
        method: 'GET',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await response.json();
  
      if (!response.ok) throw new Error(data.error || 'Error fetching user info');
  
      const { user } = data;
      document.getElementById('profile-name').value = user.name;
      document.getElementById('profile-email').value = user.email;
    } catch (err) {
      console.error(err);
      alert('Error loading user info');
    }
  }
  
  async function updateUserProfile() {
    const token = localStorage.getItem('token');
    const name = document.getElementById('profile-name').value;
    const email = document.getElementById('profile-email').value;
  
    try {
      const response = await fetch('http://localhost:3000/api/auth/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ name, email })
      });
      const data = await response.json();
  
      if (!response.ok) throw new Error(data.error || 'Error updating profile');
      alert('Profile updated successfully!');
    } catch (err) {
      console.error(err);
      alert('Error updating profile');
    }
  }
  