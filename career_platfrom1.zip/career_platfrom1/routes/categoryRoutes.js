const express = require('express');
const router = express.Router();
const categoryController = require('../controllers/categoryController');
const { verifyToken, isAdmin } = require('../middleware/authmiddleware');

// Admin: Create a new category
router.post('/', verifyToken, isAdmin, categoryController.createCategory);

// Public: Get all categories
router.get('/', categoryController.getAllCategories);

// Admin: Update a category
router.put('/:id', verifyToken, isAdmin, categoryController.updateCategory);

// Admin: Delete a category
router.delete('/:id', verifyToken, isAdmin, categoryController.deleteCategory);

module.exports = router;
