const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const { verifyToken, isAdmin } = require('../middleware/authmiddleware');

// Get all users
router.get('/users', verifyToken, isAdmin, adminController.getAllUsers);

// Get user by ID
router.get('/user/:id', verifyToken, isAdmin, adminController.getUserById);

// Delete a user
router.delete('/user/:id', verifyToken, isAdmin, adminController.deleteUser);

// Update user role
router.put('/user/:id/role', verifyToken, isAdmin, adminController.updateUserRole);

// Deactivate/Reactivate user
router.put('/user/:id/status', verifyToken, isAdmin, adminController.toggleUserStatus);

// Get admin activity logs
router.get('/logs', verifyToken, isAdmin, adminController.getAdminLogs);

module.exports = router;
