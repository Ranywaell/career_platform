// applicationRoutes.js
const express = require('express');
const router = express.Router();
const applicationController = require('../controllers/applicationController');
const { verifyToken, isAdmin, isEmployer, isJobSeeker } = require('../middleware/authmiddleware');

// Job Seeker: apply
router.post('/apply', verifyToken, isJobSeeker, applicationController.applyForJob);

// Admin or Employer: get all applications
router.get('/', verifyToken, applicationController.getAllApplications);

// New route for the job seeker’s own applications
router.get('/my', verifyToken, isJobSeeker, applicationController.getMyApplications);

// Employer: get apps for a specific listing
router.get('/listing/:listingId', verifyToken, isEmployer, applicationController.getApplicationsByListing);

// Admin: get apps by job seeker
router.get('/jobseeker/:userId', verifyToken, isAdmin, applicationController.getApplicationsByJobSeeker);

// Employer: update application status
router.put('/:id/status', verifyToken, isEmployer, applicationController.updateApplicationStatus);

module.exports = router;
