const express = require('express');
const router = express.Router();
const listingController = require('../controllers/listingController');
const { verifyToken, isEmployer } = require('../middleware/authmiddleware');

// Employer Only
router.post('/create', verifyToken, isEmployer, listingController.createListing);
router.put('/:id', verifyToken, isEmployer, listingController.updateListing);
router.delete('/:id', verifyToken, isEmployer, listingController.deleteListing);

// Public
router.get('/', listingController.getAllListings);
router.get('/:id', listingController.getListingById);

module.exports = router;
