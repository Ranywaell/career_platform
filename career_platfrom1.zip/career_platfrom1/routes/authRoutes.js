const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { verifyToken, isAdmin, isEmployer, isJobSeeker } = require('../middleware/authmiddleware');

// Public: register & login
router.post('/register', authController.registerUser);
router.post('/login', authController.loginUser);

// Profile: get user info, update
router.get('/profile', verifyToken, authController.getUserInfo);
router.put('/profile', verifyToken, authController.updateUser);

// Admin routes
router.get('/admin/users', verifyToken, isAdmin, authController.getAllUsers);
router.get('/admin/user/:id', verifyToken, isAdmin, authController.getUserById);
router.delete('/admin/user/:id', verifyToken, isAdmin, authController.deleteUser);

// Employer-specific route
router.get('/employer/dashboard', verifyToken, isEmployer, authController.getEmployerDashboard);

module.exports = router;
